@extends('common.layout')

@section('content')
    <div class="panel panel-default">
            <div class="panel-heading"><i class="fa fa-fw fa-plus"></i> 修改学生</div>
            <div class="panel-body">
                @include('common.form')
            </div>
        </div>

@stop
/**
 * 初始化
 * Created by boser on 2017/5/14.
 */
$(function(){
    $('[data-toggle]').tooltip();
});
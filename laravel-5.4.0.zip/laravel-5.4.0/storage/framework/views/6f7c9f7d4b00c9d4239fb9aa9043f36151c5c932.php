<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
    header
<?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?>
    sidebar
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    main
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
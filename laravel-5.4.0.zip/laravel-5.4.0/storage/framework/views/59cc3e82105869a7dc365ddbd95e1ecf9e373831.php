<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
            <div class="panel-heading"><i class="fa fa-fw fa-plus"></i> 修改学生</div>
            <div class="panel-body">
                <?php echo $__env->make('common.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
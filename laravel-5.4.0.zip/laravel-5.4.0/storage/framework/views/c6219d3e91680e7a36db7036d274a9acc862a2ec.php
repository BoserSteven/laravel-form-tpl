<?php $__env->startSection('title'); ?>
    首页
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading"><i class="fa fa-fw fa-users"></i> 学生列表</div>
        <table class="table table-responsive table-hover">
            <tr>
                <th>ID</th>
                <th>姓名</th>
                <th>性别</th>
                <th>年龄</th>
                <th>操作</th>
            </tr>
            <?php $__currentLoopData = $ret; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($v->id); ?></td>
                <td><?php echo e($v->name); ?></td>
                <td><?php echo e($v->hdlSex($v->sex)); ?></td>
                <td><?php echo e($v->age); ?></td>
                <td>
                    <a href="<?php echo e(url('Student/detail', ['id' => $v->id])); ?>" class="btn btn-default btn-xs">详情</a>
                    <a href="<?php echo e(url('Student/update', ['id' => $v->id])); ?>" class="btn btn-default btn-xs">修改</a>
                    <a href="<?php echo e(url('Student/delete', ['id' => $v->id])); ?>" class="btn btn-danger btn-xs" onclick="return confirm('is del or not???')">删除</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>

    </div>
    <div class="pull-right">
        <?php echo e($ret->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
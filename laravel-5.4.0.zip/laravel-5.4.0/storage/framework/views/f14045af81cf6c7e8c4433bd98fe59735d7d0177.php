<?php $__env->startSection('content'); ?>
    <div class="panel panel-default">
        <div class="panel-heading"><i class="fa fa-fw fa-archive"></i> 学生详情</div>
        <table class="table table-responsive table-bordered table-hover">
            <tr>
                <td>id</td>
                <td><?php echo e($ret->id); ?></td>
            </tr>
            <tr>
                <td>姓名</td>
                <td><?php echo e($ret->name); ?></td>
            </tr>
            <tr>
                <td>性别</td>
                <td><?php echo e($ret->hdlSex($ret->sex)); ?></td>
            </tr>
            <tr>
                <td>年龄</td>
                <td><?php echo e($ret->age); ?></td>
            </tr>
            <tr>
                <td>添加日期</td>
                <td><?php echo e(date('Y-m-d H:i', $ret->created_at)); ?></td>
            </tr>
            <tr>
                <td>最后修改</td>
                <td><?php echo e(date('Y-m-d H:i', $ret->updated_at)); ?></td>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('common.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
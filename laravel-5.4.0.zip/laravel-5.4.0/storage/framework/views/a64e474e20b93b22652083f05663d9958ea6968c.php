<form class="form-horizontal" method="post" action="">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="姓名" class="col-sm-2 control-label">姓名</label>
        <div class="col-sm-3">
            <input type="text" class="form-control" id="姓名" name="name" value="<?php echo e(old('name') ? old('name') : $ret->name); ?>" placeholder="姓名">
        </div>
    </div>

    <div class="form-group">
        <label for="年龄" class="col-sm-2 control-label">年龄</label>
        <div class="col-sm-3">
            <input type="number" class="form-control" id="年龄" name="age" value="<?php echo e(old('age') ? old('age') : $ret->age); ?>" placeholder="年龄">
        </div>
    </div>

    <div class="form-group">
        <label class="col-sm-2 control-label">性别</label>
        <div class="col-sm-3">
            <div class="checkbox">
                <?php $__currentLoopData = $stu_ins->hdlSex(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label>
                        <input type="radio" name="sex" value="<?php echo e($k); ?>"
                        <?php if($ret->sex == $k): ?>
                            checked
                        <?php endif; ?>
                        > <?php echo e($v); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <div class="form-group">
        <div class="col-sm-offset-2 col-sm-3">
            <button type="submit" class="btn btn-primary"><i class="fa fa-fw fa-drupal"></i> 提交</button>
        </div>
    </div>
</form>